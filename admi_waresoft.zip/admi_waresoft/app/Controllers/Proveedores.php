<?php

namespace App\Controllers;
use App\Models\ProveedoresModel;

class Proveedores extends BaseController
{
	public function index()
    {    

        $proveedor = new ProveedoresModel();
        $data['proveedores'] = $proveedor->findAll();
        $this->vistas('index',$data);

    }
    
    public function registrar()
    {
        $this->vistas('registrar',[]);
        
    }

    public function newProveedor()
    {

        $proveedor = new ProveedoresModel();
        $data = [
            
            'nrc' => $this->request->getPost('nrc'),
            'nit_proveedor' => $this->request->getPost('nit_proveedor'),
            'nombre_comercial' => $this->request->getPost('nombre_comercial'),
            'nombre_legal' => $this->request->getPost('nombre_legal'),
            'telefono' => $this->request->getPost('telefono'),
            'correo' => $this->request->getPost('correo'),
            'direccion' => $this->request->getPost('direccion'),
            'departamento' => $this->request->getPost('departamento'),
            'municipio' => $this->request->getPost('municipio')
        ];
        $proveedor->save($data);
        return redirect()->to(base_url('proveedores'))->with('status', 'Proveedore agregado correctamente');
        
    }

    public function editProveedor($id_proveedor)
    {
        $proveedor = new ProveedoresModel();
        $data['proveedores'] = $proveedor->findAll($id_proveedor);
        $this->vistas('editar',[$data]);
    }

    private function vistas($view,$data){
        
       // $loginModel = new LoginModel();
        //$data ['data'] = $loginModel->countAllResults();
        echo view("template/header");
        echo view("template/menu");
		echo view("proveedores/$view",$data);
        echo view("template/footer");
    }
}
