<?php

namespace App\Models;

use CodeIgniter\Model;

class ProveedoresModel extends Model
{
    protected $table = 'proveedores';
    protected $primarykey = 'id_proveedor';
    protected $allowedFields = [
        'nrc',
        'nit_proveedor',
        'nombre_comercial',
        'nombre_legal',
        'telefono',
        'correo',
        'direccion',
        'departamento',
        'municipio'
    ];
    
}