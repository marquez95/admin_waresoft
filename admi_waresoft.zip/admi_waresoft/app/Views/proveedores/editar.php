<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Proveedor | <small>Registro</small> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url("/")?>">Inicio</a></li>
                        <li class="breadcrumb-item active">Registrar proveedores</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <?php echo $proveedores; ?>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <!-- /.card-header -->
                <div class="card-body">
                    <form action="<?= base_url("agregarProveedor")?>" method="POST">
                        <h4>Datos Legales</h4>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="nrc" id="nrc" placeholder="NRC Proveedor" title="Escribir número con guiones" required>
                                <small class="form-text text-muted">*Número de Registro de Contribuyente (con guiones).</small>
                            </div>
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="nit_proveedor" id="nit_proveedor" placeholder="NIT Proveedor" title="Escribir número con guiones" required>
                                <small class="form-text text-muted">*Número de Indentificación Tributaria (con guiones).</small>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="nombre_comercial" id="nombre_comercial" placeholder="Nombre comercial del proveedor" title="Nombre comercial del proveedor" required>
                            <small class="form-text text-muted">*Nombre comercial del proveedor.</small>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="nombre_legal" id="nombre_legal" placeholder="Nombre legal del proveedor" title="Nombre legal del proveedor" required>
                            <small class="form-text text-muted">*Nombre legal del proveedor.</small>
                        </div>
                        <h4>Información de contacto</h4>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <input type="number" class="form-control" name="telefono" id="telefono" placeholder="Teléfono" title="Escribir número de teléfono" required>
                                <small class="form-text text-muted">*Número de teléfono.</small>
                            </div>
                            <div class="form-group col-md-6">
                                <input type="email" class="form-control" name="correo" id="correo" placeholder="Correo electrónico" title="Escribir correo electrónico">
                                <small class="form-text text-muted">Correo electrónico.</small>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Dirección" title="Escribir dirección completa del proveedor" required>
                            <small class="form-text text-muted">*Dirección completa.</small>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="departamento" id="departamento" placeholder="Departamento" title="Escribir departamento de ubicación segun NRC" required>
                                <small class="form-text text-muted">*Departamento de ubicación.</small>
                            </div>
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="municipio" id="municipio" placeholder="Municipio" title="Escribir municipio de ubicación segun NRC" required>
                                <small class="form-text text-muted">*Municipio de ubicación.</small>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-block btn-success">Actualizar proveedor</button>
                    </form>
                    <!-- /.row -->
                </div>
                <!-- /.card-body -->
                
            </div>
            <!-- /.card -->
            <!-- /.card -->    
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
