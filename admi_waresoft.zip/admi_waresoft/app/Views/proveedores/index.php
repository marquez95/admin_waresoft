<!-- Content Wrapper. Contains page content -->

<div class="content-wrapper">

  <!-- Content Header (Page header) -->
  <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Proveedores | <small>Listado</small> </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url("/")?>">Inicio</a></li>
                        <li class="breadcrumb-item active">Listado proveedores</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <?php
        if (session()->getFlashdata('status')) {
            echo "<h4>".session()->getFlashdata('status')."</h4>";
        }
    ?>
    <div class="card">
        
              <div class="card-body">
                <table class="table table-bordered table-striped">
                <thead>
                            <tr>
                                <th>NRC</th>
                                <th>NOMBRE COMERCIAL</th>
                                <th>TELEFONO</th>
                                <th>CORREO</th>
                                <th>DIRECCION</th>
                                
                                
                            </tr>
                            
                            <?php foreach($proveedores as $datos): ?>
                        <tbody>
                            <tr>
                                <td><?= $datos['nrc'] ?></td>
                                <td><?= $datos['nombre_comercial'] ?></td>
                                <td><?= $datos['telefono'] ?></td>
                                <td><?= $datos['correo'] ?></td>
                                <td><?= $datos['direccion'] ?></td>                            
                                <td>
                                    <a href="<?= base_url('Proveedores/editProveedor/'.$datos['id_proveedor'])?>" class="btn btn-success btn-sm">Editar</a>
                                </td>
                                <td>
                                    <a href="" class="btn btn-danger btn-sm">Eliminar</a>
                                </td>
                            </tr>
                        </tbody>
                        <?php endforeach; ?>
                        </thead>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->