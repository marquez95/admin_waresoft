<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
	public function index()
    {        
        $this->vistas('index',[]);
        
       
    }

    private function vistas(/*$data,*/$view){
        
       // $loginModel = new LoginModel();
        //$data ['data'] = $loginModel->countAllResults();
        echo view("template/header");
        echo view("template/menu");
		echo view("dashboard/$view");
        echo view("template/footer");
    }
}
