<?php

namespace App\Controllers;
use App\Models\ProveedoresModel;

class Proveedores extends BaseController
{
	public function index()
    {    

        $proveedor = new ProveedoresModel();
        $data = ['datos' => $proveedor->asObject()->get()];
        $this->vistas('index',$data);

    }
    
    public function registrar()
    {
        $this->vistas('registrar',[]);
        
    }

    public function newProveedor()
    {

        
        
    }

    public function show()
    {
        $proveedor = new ProveedoresModel();
        var_dump($proveedor->get());
    }

    private function vistas($view,$data){
        
       // $loginModel = new LoginModel();
        //$data ['data'] = $loginModel->countAllResults();
        echo view("template/header");
        echo view("template/menu");
		echo view("proveedores/$view",$data);
        echo view("template/footer");
    }
}
