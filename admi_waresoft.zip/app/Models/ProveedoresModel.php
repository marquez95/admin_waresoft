<?php

namespace App\Models;

use CodeIgniter\Model;

class ProveedoresModel extends Model
{
    protected $table = 'proveedores';
    protected $primarykey = 'id_proveedor';
    
    public function get($id_proveedor = null)
    {
        if ($id_proveedor === null) {
            return $this->findAll();
        }
        return $this->asArray()->where(['id_proveedor' => $id_proveedor])->first();
    }
}