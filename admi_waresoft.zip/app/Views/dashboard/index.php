<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

  <!-- Content Header (Page header) -->
  <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Waresoft S.A. de C.V.</h1>
            </div><!-- /.col -->
          </div><!-- /.row -->
      </div>
    <!-- /.container-fluid -->
  </div>
    <!-- /.content-header -->
  <!-- /.content-header -->
   <!-- Contenido -->
   <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <div class="row">

                <!-- caja crédito fiscal -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>0</h3>

                            <p>Crédito Fiscal</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-file-invoice"></i>
                        </div>
                        <a href="@Url.Action("Registrar", "Creditofiscal")" class="small-box-footer">Registrar <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- caja Factura, tickets, otros -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>0<sup style="font-size: 20px"></sup></h3>

                            <p>Factura, tickets, otros</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-receipt"></i>
                        </div>
                        <a href="@Url.Action("Registrar", "facturaticketsotros")" class="small-box-footer">Registrar <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- caja Caja chica -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-gradient-lightblue">
                        <div class="inner">
                            <h3>$23.36</h3>

                            <p>Caja chica</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-cash-register"></i>
                        </div>
                        <a href="@Url.Action("Registrar", "Cajachica")" class="small-box-footer">Registrar movimiento <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- caja Proveedores -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3>0</h3>

                            <p>Proveedores</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-truck-moving"></i>
                        </div>
                        <a href="<?= base_url("registroProveedores")?>" class="small-box-footer">Registrar <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- caja Planilla -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-gradient-indigo">
                        <div class="inner">
                            <h3>1</h3>

                            <p>Planilla</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                        <a href="@Url.Action("Index", "Planilla")" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- caja Recibo de pago -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-gradient-teal">
                        <div class="inner">
                            <h3>0</h3>

                            <p>Recibo de pago</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-file-invoice-dollar"></i>
                        </div>
                        <a href="@Url.Action("Index", "Generarecibo")" class="small-box-footer">Generar <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- caja Contacto-->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-gradient-maroon">
                        <div class="inner">
                            <h3>1</h3>

                            <p>Contactos</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-address-card"></i>
                        </div>
                        <a href="@Url.Action("Contacto", "Planilla")" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
